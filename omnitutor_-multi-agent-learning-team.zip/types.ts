
export type AgentRole = 
  | 'SUPERVISOR' 
  | 'DOCUMENT_ANALYZER' 
  | 'EXPLANATION_ENGINE' 
  | 'QUIZ_MASTER' 
  | 'FLASHCARD_CREATOR' 
  | 'CRITIC';

export type TutorMode = 'EXPLANATION' | 'SUMMARY' | 'QUIZ' | 'FLASHCARDS';

export interface DocumentInfo {
  name: string;
  base64: string;
  mimeType: string;
}

export interface Flashcard {
  front: string;
  back: string;
}

export interface SharedState {
  document?: DocumentInfo;
  active_mode: TutorMode;
  explanation: string;
  summary: string;
  quiz_questions: QuizQuestion[];
  flashcards: Flashcard[];
  student_answers: string[];
  feedback: string;
  feedback_logs: UserFeedback[];
}

export interface UserFeedback {
  agentRole: AgentRole;
  content: string;
  rating: 'helpful' | 'unhelpful';
  timestamp: Date;
}

export interface QuizQuestion {
  question: string;
  options?: string[];
  answer: string;
  type: 'multiple_choice' | 'short_answer';
}

export interface AgentResponse {
  agent: AgentRole;
  content: string;
  updatedState?: Partial<SharedState>;
  nextAgent?: AgentRole | 'USER';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'agent';
  agentRole?: AgentRole;
  content: string;
  timestamp: Date;
  userRating?: 'helpful' | 'unhelpful';
}
