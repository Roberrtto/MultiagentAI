
import { GoogleGenAI, Type } from "@google/genai";
import { SharedState, AgentResponse, AgentRole } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_PROMPT = `
You are a multi-agent AI document tutor team.
Roles: 
- SUPERVISOR: Orchestrates based on requested mode (EXPLANATION, SUMMARY, QUIZ, FLASHCARDS).
- DOCUMENT_ANALYZER: Reads the provided file and summarizes its core structure.
- EXPLANATION_ENGINE: Creates detailed notes or explanations.
- QUIZ_MASTER: Generates questions.
- FLASHCARD_CREATOR: Creates front/back pairs.
- CRITIC: Validates output against the source.

RULES:
- You must simulate ONLY ONE agent at a time.
- All information generated MUST come from the attached document.
- Return output in valid JSON format only.
`;

export async function getAgentTurn(
  requestedRole: AgentRole,
  state: SharedState,
  userMessage?: string
): Promise<AgentResponse> {
  const model = 'gemini-3-pro-preview';
  
  const contents: any[] = [
    { text: `CURRENT ROLE: ${requestedRole}` },
    { text: `SHARED STATE (Memory): ${JSON.stringify({ ...state, document: undefined })}` }, // Strip doc for JSON prompt to save tokens
  ];

  if (state.document) {
    contents.push({
      inlineData: {
        data: state.document.base64,
        mimeType: state.document.mimeType
      }
    });
  }

  if (userMessage) {
    contents.push({ text: `USER INPUT: ${userMessage}` });
  }

  const prompt = `
    Task: Execute ${requestedRole} logic.
    Active Mode: ${state.active_mode}.
    
    If you are FLASHCARD_CREATOR, populate updatedState.flashcards.
    If you are QUIZ_MASTER, populate updatedState.quiz_questions.
    If you are EXPLANATION_ENGINE, populate updatedState.explanation or updatedState.summary.

    Return JSON:
    {
      "agent": "${requestedRole}",
      "content": "Narrative text for user",
      "updatedState": { ... },
      "nextAgent": "AgentRole or 'USER'"
    }
  `;
  contents.push({ text: prompt });

  const response = await ai.models.generateContent({
    model,
    contents: { parts: contents },
    config: {
      systemInstruction: SYSTEM_PROMPT,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          agent: { type: Type.STRING },
          content: { type: Type.STRING },
          updatedState: { 
            type: Type.OBJECT,
            properties: {
              explanation: { type: Type.STRING },
              summary: { type: Type.STRING },
              flashcards: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { front: { type: Type.STRING }, back: { type: Type.STRING } } } },
              quiz_questions: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { question: { type: Type.STRING }, answer: { type: Type.STRING }, type: { type: Type.STRING }, options: { type: Type.ARRAY, items: { type: Type.STRING } } } } },
              feedback: { type: Type.STRING }
            }
          },
          nextAgent: { type: Type.STRING }
        },
        required: ["agent", "content", "nextAgent"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim());
  } catch (error) {
    console.error("Parse Error:", response.text);
    throw new Error("Coordination Failure");
  }
}
