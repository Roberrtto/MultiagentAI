
import React, { useState, useEffect, useRef } from 'react';
import { 
  BrainCircuit, 
  Send, 
  RefreshCcw, 
  FileUp, 
  Sparkles,
  CheckCircle2,
  ArrowRight,
  User,
  // Added missing 'Users' icon import
  Users,
  FileText,
  HelpCircle,
  Copy,
  Layers,
  ChevronLeft,
  ChevronRight,
  Zap,
  Check
} from 'lucide-react';
import { 
  SharedState, 
  AgentRole, 
  ChatMessage, 
  TutorMode,
  DocumentInfo
} from './types';
import { AGENT_METADATA } from './constants';
import { getAgentTurn } from './services/gemini';

const INITIAL_STATE: SharedState = {
  active_mode: 'EXPLANATION',
  explanation: '',
  summary: '',
  quiz_questions: [],
  flashcards: [],
  student_answers: [],
  feedback: '',
  feedback_logs: []
};

export default function App() {
  const [file, setFile] = useState<File | null>(null);
  const [isStarted, setIsStarted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [state, setState] = useState<SharedState>(INITIAL_STATE);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [activeAgent, setActiveAgent] = useState<AgentRole | 'USER' | null>(null);
  const [activeChain, setActiveChain] = useState<AgentRole[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [flashcardIdx, setFlashcardIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, activeAgent]);

  const addMessage = (role: 'user' | 'agent', content: string, agentRole?: AgentRole) => {
    const newMessage: ChatMessage = {
      id: Math.random().toString(36).substring(7),
      role,
      content,
      agentRole,
      timestamp: new Date()
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) setFile(selectedFile);
  };

  const startSession = async (initialMode: TutorMode) => {
    if (!file) return;
    setLoading(true);
    setIsStarted(true);

    const reader = new FileReader();
    reader.onload = async (e) => {
      const base64 = (e.target?.result as string).split(',')[1];
      const doc: DocumentInfo = {
        name: file.name,
        base64,
        mimeType: file.type
      };

      const newState = { ...INITIAL_STATE, document: doc, active_mode: initialMode };
      setState(newState);
      
      // Initial greeting and analysis
      processAgentChain('SUPERVISOR', newState);
    };
    reader.readAsDataURL(file);
  };

  const processAgentChain = async (startRole: AgentRole, currentState: SharedState, userMsg?: string) => {
    let currentRole: AgentRole | 'USER' = startRole;
    let localState = { ...currentState };
    let chain: AgentRole[] = [];
    
    if (startRole === 'SUPERVISOR') {
      setActiveChain(['SUPERVISOR']);
      chain = ['SUPERVISOR'];
    } else {
      chain = [...activeChain];
    }

    setLoading(true);

    while (currentRole !== 'USER') {
      setActiveAgent(currentRole);
      if (!chain.includes(currentRole as AgentRole)) {
        chain.push(currentRole as AgentRole);
        setActiveChain([...chain]);
      }
      
      try {
        const turn = await getAgentTurn(currentRole as AgentRole, localState, userMsg);
        if (turn.updatedState) {
          localState = { ...localState, ...turn.updatedState };
          setState(localState);
        }
        addMessage('agent', turn.content, turn.agent);
        currentRole = turn.nextAgent || 'USER';
        if (currentRole !== 'USER') await new Promise(r => setTimeout(r, 800));
      } catch (err) {
        addMessage('agent', "Team encountered a hiccup. Please retry.", 'SUPERVISOR');
        currentRole = 'USER';
      }
    }

    setActiveAgent('USER');
    setLoading(false);
  };

  const handleModeSwitch = (newMode: TutorMode) => {
    if (state.active_mode === newMode) return;
    
    const newState = { ...state, active_mode: newMode };
    setState(newState);
    
    // Check if we already have content for this mode
    const hasContent = 
      (newMode === 'EXPLANATION' && state.explanation) ||
      (newMode === 'SUMMARY' && state.summary) ||
      (newMode === 'QUIZ' && state.quiz_questions.length > 0) ||
      (newMode === 'FLASHCARDS' && state.flashcards.length > 0);

    if (!hasContent) {
      addMessage('agent', `Switching to ${newMode.toLowerCase()} mode. My team is preparing the content now...`, 'SUPERVISOR');
      processAgentChain('SUPERVISOR', newState, `Generate ${newMode.toLowerCase()} for the document.`);
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || loading) return;
    const msg = inputValue;
    setInputValue('');
    addMessage('user', msg);
    processAgentChain('SUPERVISOR', state, msg);
  };

  if (!isStarted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50 flex items-center justify-center p-6">
        <div className="max-w-xl w-full bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 p-8 md:p-12 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-indigo-600 rounded-3xl shadow-xl mb-8 transform rotate-3 hover:rotate-0 transition-transform">
            <BrainCircuit className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tight">OmniTutor</h1>
          <p className="text-lg text-slate-500 mb-10 leading-relaxed">
            Upload a document and let our team of agents assist you with multiple study tools.
          </p>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={`border-3 border-dashed rounded-[2rem] p-10 cursor-pointer transition-all mb-8 ${file ? 'border-emerald-400 bg-emerald-50' : 'border-slate-200 bg-slate-50 hover:bg-slate-100 hover:border-indigo-300'}`}
          >
            <input type="file" ref={fileInputRef} className="hidden" accept=".pdf" onChange={handleFileUpload} />
            {file ? (
              <div className="flex flex-col items-center">
                <FileText className="w-12 h-12 text-emerald-600 mb-3" />
                <span className="text-sm font-bold text-emerald-800">{file.name}</span>
                <span className="text-[10px] text-emerald-600 font-bold uppercase mt-1">Ready to process</span>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <FileUp className="w-12 h-12 text-indigo-400 mb-3" />
                <span className="text-sm font-bold text-slate-600">Drop a PDF here</span>
                <span className="text-xs text-slate-400 mt-1 italic">Max size: 10MB</span>
              </div>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              disabled={!file} 
              onClick={() => startSession('EXPLANATION')}
              className="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-indigo-500 hover:bg-indigo-50 transition-all disabled:opacity-30 disabled:pointer-events-none"
            >
              <FileText className="w-6 h-6 text-indigo-600 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-700">Explainer</span>
            </button>
            <button 
              disabled={!file} 
              onClick={() => startSession('QUIZ')}
              className="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-purple-500 hover:bg-purple-50 transition-all disabled:opacity-30 disabled:pointer-events-none"
            >
              <HelpCircle className="w-6 h-6 text-purple-600 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-700">Quiz</span>
            </button>
            <button 
              disabled={!file} 
              onClick={() => startSession('FLASHCARDS')}
              className="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-rose-500 hover:bg-rose-50 transition-all disabled:opacity-30 disabled:pointer-events-none"
            >
              <Layers className="w-6 h-6 text-rose-600 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-700">Cards</span>
            </button>
            <button 
              disabled={!file} 
              onClick={() => startSession('SUMMARY')}
              className="group flex flex-col items-center gap-2 p-4 rounded-2xl border-2 border-slate-100 hover:border-emerald-500 hover:bg-emerald-50 transition-all disabled:opacity-30 disabled:pointer-events-none"
            >
              <Copy className="w-6 h-6 text-emerald-600 group-hover:scale-110 transition-transform" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-700">Summary</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col md:flex-row bg-slate-50 overflow-hidden">
      {/* Sidebar: Study Tools & Results */}
      <aside className="w-full md:w-96 bg-white border-r border-slate-200 flex flex-col h-[50vh] md:h-full z-20 shadow-xl">
        <div className="p-4 md:p-6 border-b border-slate-100 bg-white">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
              <FileText className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h2 className="font-bold text-slate-800 text-sm truncate">{state.document?.name}</h2>
              <div className="flex items-center gap-1.5 text-[9px] font-black text-indigo-500 uppercase tracking-widest">
                <Zap className="w-3 h-3 fill-current" />
                Live Analysis active
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 rounded-xl">
            {(['EXPLANATION', 'SUMMARY', 'QUIZ', 'FLASHCARDS'] as TutorMode[]).map((mode) => {
              const active = state.active_mode === mode;
              const hasData = 
                (mode === 'EXPLANATION' && state.explanation) ||
                (mode === 'SUMMARY' && state.summary) ||
                (mode === 'QUIZ' && state.quiz_questions.length > 0) ||
                (mode === 'FLASHCARDS' && state.flashcards.length > 0);

              return (
                <button
                  key={mode}
                  onClick={() => handleModeSwitch(mode)}
                  className={`relative flex flex-col items-center gap-1.5 py-2.5 rounded-lg transition-all ${active ? 'bg-white shadow-sm text-indigo-600' : 'text-slate-400 hover:text-slate-600 hover:bg-white/50'}`}
                >
                  {mode === 'EXPLANATION' && <FileText className="w-4 h-4" />}
                  {mode === 'SUMMARY' && <Copy className="w-4 h-4" />}
                  {mode === 'QUIZ' && <HelpCircle className="w-4 h-4" />}
                  {mode === 'FLASHCARDS' && <Layers className="w-4 h-4" />}
                  <span className="text-[8px] font-black uppercase tracking-tighter">
                    {mode === 'EXPLANATION' ? 'Notes' : mode === 'FLASHCARDS' ? 'Cards' : mode}
                  </span>
                  {hasData && (
                    <div className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full border border-white shadow-sm" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 md:p-6 custom-scrollbar bg-slate-50/30">
          {/* Dynamic Content Views */}
          {state.active_mode === 'FLASHCARDS' && (
            state.flashcards.length > 0 ? (
              <div className="space-y-6">
                <div 
                  onClick={() => setIsFlipped(!isFlipped)}
                  className={`h-56 relative cursor-pointer transition-all duration-700 preserve-3d group ${isFlipped ? 'rotate-y-180' : ''}`}
                >
                  <div className="absolute inset-0 backface-hidden bg-white rounded-3xl shadow-lg border border-slate-200 flex flex-col items-center justify-center p-8 text-center group-hover:shadow-indigo-100 transition-shadow">
                    <p className="text-base font-bold text-slate-800 leading-tight">{state.flashcards[flashcardIdx].front}</p>
                    <div className="mt-6 text-[9px] font-black text-slate-300 uppercase tracking-widest flex items-center gap-2">
                      <Zap className="w-3 h-3 fill-slate-200" /> Click to reveal back
                    </div>
                  </div>
                  <div className="absolute inset-0 backface-hidden rotate-y-180 bg-indigo-600 rounded-3xl shadow-xl flex items-center justify-center p-8 text-center text-white">
                    <p className="text-base font-medium leading-relaxed">{state.flashcards[flashcardIdx].back}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between bg-white px-4 py-3 rounded-2xl border border-slate-100 shadow-sm">
                  <button 
                    onClick={() => { setFlashcardIdx(p => Math.max(0, p-1)); setIsFlipped(false); }}
                    className="p-2.5 bg-slate-50 rounded-xl hover:bg-slate-100 disabled:opacity-20 transition-colors"
                    disabled={flashcardIdx === 0}
                  >
                    <ChevronLeft className="w-5 h-5 text-slate-600" />
                  </button>
                  <div className="text-center">
                    <span className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em]">
                      Card {flashcardIdx + 1} of {state.flashcards.length}
                    </span>
                  </div>
                  <button 
                    onClick={() => { setFlashcardIdx(p => Math.min(state.flashcards.length-1, p+1)); setIsFlipped(false); }}
                    className="p-2.5 bg-slate-50 rounded-xl hover:bg-slate-100 disabled:opacity-20 transition-colors"
                    disabled={flashcardIdx === state.flashcards.length - 1}
                  >
                    <ChevronRight className="w-5 h-5 text-slate-600" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-10">
                <Layers className="w-12 h-12 mb-4 text-slate-300" />
                <p className="text-sm font-bold">No cards generated yet.</p>
                <p className="text-xs px-8 mt-2">Switch to Flashcards mode to let the agent team distill key points.</p>
              </div>
            )
          )}

          {(state.active_mode === 'EXPLANATION' || state.active_mode === 'SUMMARY') && (
            <div className="animate-in fade-in duration-500">
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm whitespace-pre-wrap text-slate-700 leading-relaxed text-sm selection:bg-indigo-100">
                {state.active_mode === 'EXPLANATION' 
                  ? (state.explanation || "Agent Team is drafting notes...") 
                  : (state.summary || "Agent Team is condensing document...")}
              </div>
            </div>
          )}

          {state.active_mode === 'QUIZ' && (
            state.quiz_questions.length > 0 ? (
              <div className="space-y-4 pb-10">
                {state.quiz_questions.map((q, i) => (
                  <div key={i} className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm hover:border-indigo-200 transition-colors group">
                    <div className="flex gap-3 mb-4">
                      <span className="flex-shrink-0 w-6 h-6 rounded-lg bg-indigo-50 text-indigo-600 text-[10px] font-black flex items-center justify-center">
                        {i + 1}
                      </span>
                      <p className="text-sm font-bold text-slate-900">{q.question}</p>
                    </div>
                    {q.options?.map((opt, oi) => (
                      <div key={oi} className="flex items-center gap-3 p-3 rounded-2xl border border-slate-50 hover:bg-indigo-50 hover:border-indigo-100 cursor-pointer mb-2 last:mb-0 transition-all group/opt">
                        <div className="w-5 h-5 rounded-full border-2 border-slate-200 group-hover/opt:border-indigo-400 flex-shrink-0 flex items-center justify-center">
                          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 scale-0 group-hover/opt:scale-100 transition-transform" />
                        </div>
                        <span className="text-[11px] text-slate-600 font-medium">{opt}</span>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center opacity-40 py-10">
                <HelpCircle className="w-12 h-12 mb-4 text-slate-300" />
                <p className="text-sm font-bold">Waiting for Quiz Master.</p>
                <p className="text-xs px-8 mt-2">Toggle to Quiz mode to trigger automated test generation.</p>
              </div>
            )
          )}
        </div>

        <div className="p-4 bg-white border-t border-slate-100">
          <button 
            onClick={() => window.location.reload()}
            className="w-full py-3.5 bg-slate-50 text-slate-500 rounded-2xl font-bold text-[10px] uppercase tracking-widest hover:bg-slate-100 hover:text-slate-800 transition-all flex items-center justify-center gap-2 group"
          >
            <RefreshCcw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
            Upload New Source
          </button>
        </div>
      </aside>

      {/* Main Content: Multi-Agent Collaboration */}
      <main className="flex-1 flex flex-col min-w-0 bg-white relative z-10 shadow-2xl">
        <div className="h-16 md:h-20 border-b border-slate-100 flex items-center px-4 md:px-8 bg-white/80 backdrop-blur-md sticky top-0 z-30">
          <div className="w-full flex items-center justify-between">
            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-2">
              {activeChain.map((role, idx) => {
                const meta = AGENT_METADATA[role];
                const isActive = activeAgent === role;
                return (
                  <React.Fragment key={idx}>
                    <div className={`flex items-center gap-2 px-3.5 py-2 rounded-xl border transition-all ${isActive ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100 scale-105' : 'bg-slate-50 text-slate-400 border-slate-100'}`}>
                      <div className={isActive ? 'animate-pulse' : ''}>{meta.icon}</div>
                      <span className="text-[10px] font-black uppercase tracking-widest whitespace-nowrap">{meta.name}</span>
                    </div>
                    {idx < activeChain.length - 1 && <ArrowRight className="w-3 h-3 text-slate-200 flex-shrink-0" />}
                  </React.Fragment>
                );
              })}
            </div>
            
            <div className="hidden lg:flex items-center gap-3 ml-4">
              <div className="flex flex-col items-end">
                <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest leading-none mb-1">Session Integrity</span>
                <div className="flex gap-1">
                  <Check className="w-3 h-3 text-emerald-500" />
                  <Check className="w-3 h-3 text-emerald-500" />
                  <Check className="w-3 h-3 text-emerald-500" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Messaging Interface */}
        <div className="flex-1 overflow-y-auto p-4 md:p-10 space-y-10 custom-scrollbar scroll-smooth">
          {messages.map((msg, i) => {
            const isUser = msg.role === 'user';
            const meta = isUser ? AGENT_METADATA.USER : AGENT_METADATA[msg.agentRole || 'SUPERVISOR'];
            return (
              <div key={msg.id} className={`flex ${isUser ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
                <div className={`flex gap-5 max-w-[90%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-sm border ${meta.borderColor} ${meta.bgColor} ${meta.color} transform transition-transform hover:scale-110`}>
                    {meta.icon}
                  </div>
                  <div className={`space-y-2 ${isUser ? 'items-end' : 'items-start'}`}>
                    <div className="flex items-center gap-2 px-1">
                      <span className={`text-[9px] font-black uppercase tracking-[0.2em] ${isUser ? 'text-indigo-400' : 'text-slate-400'}`}>{meta.name}</span>
                      <span className="text-[9px] text-slate-300 font-bold">{msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <div className={`p-5 md:p-6 rounded-[2rem] whitespace-pre-wrap leading-relaxed shadow-sm transition-all duration-300 ${
                      isUser 
                        ? 'bg-indigo-600 text-white rounded-tr-none shadow-indigo-100' 
                        : 'bg-white border border-slate-100 text-slate-800 rounded-tl-none hover:shadow-md hover:border-indigo-100'
                    }`}>
                      {msg.content}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
          {loading && (
            <div className="flex items-center gap-4 text-indigo-500 animate-pulse bg-indigo-50/50 w-fit px-6 py-3 rounded-full border border-indigo-100">
              <Users className="w-5 h-5" /> 
              <span className="text-[11px] font-black uppercase tracking-[0.15em]">Team Collaborative Analysis...</span>
            </div>
          )}
          <div ref={messagesEndRef} className="h-6" />
        </div>

        {/* Multi-Purpose Input */}
        <div className="p-4 md:p-10 bg-white border-t border-slate-100">
          <form onSubmit={handleSendMessage} className="max-w-4xl mx-auto flex items-center gap-4">
            <div className="flex-1 relative group">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={loading ? "Waiting for agents..." : "Ask a specific question about your file..."}
                disabled={loading}
                className="w-full pl-8 pr-16 py-5 md:py-6 bg-slate-50 border-2 border-transparent rounded-[2.5rem] focus:bg-white focus:border-indigo-500 transition-all outline-none text-slate-800 font-medium placeholder-slate-400 shadow-inner"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2">
                <button
                  type="submit"
                  disabled={loading || !inputValue.trim()}
                  className={`w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center transition-all shadow-xl ${
                    loading || !inputValue.trim() 
                    ? 'bg-slate-200 text-slate-400' 
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 hover:scale-105 active:scale-95 shadow-indigo-200'
                  }`}
                >
                  {loading ? <RefreshCcw className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5 md:w-6 md:h-6" />}
                </button>
              </div>
            </div>
          </form>
          
          <div className="mt-8 flex flex-wrap justify-center gap-8 text-[9px] font-black uppercase tracking-[0.25em] text-slate-300">
            <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-400" /> Source-Grounded AI</div>
            <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-400" /> Multi-Turn Context</div>
            <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-indigo-400" /> Verification Layer</div>
          </div>
        </div>
      </main>

      <style>{`
        .rotate-y-180 { transform: rotateY(180deg); }
        .backface-hidden { backface-visibility: hidden; }
        .preserve-3d { transform-style: preserve-3d; }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }
      `}</style>
    </div>
  );
}
