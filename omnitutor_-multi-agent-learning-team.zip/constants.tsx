
import React from 'react';
import { 
  ShieldCheck, 
  FileSearch, 
  Lightbulb, 
  CheckSquare, 
  Layout, 
  MessageSquareQuote,
  User
} from 'lucide-react';
import { AgentRole } from './types';

export const AGENT_METADATA: Record<AgentRole | 'USER', { 
  name: string; 
  icon: React.ReactNode; 
  color: string; 
  borderColor: string;
  bgColor: string;
  description: string;
}> = {
  SUPERVISOR: {
    name: 'Coordinator',
    icon: <ShieldCheck className="w-5 h-5" />,
    color: 'text-indigo-600',
    borderColor: 'border-indigo-500',
    bgColor: 'bg-indigo-50',
    description: 'Manages document intake and coordinates specialized agents.'
  },
  DOCUMENT_ANALYZER: {
    name: 'Doc Analyst',
    icon: <FileSearch className="w-5 h-5" />,
    color: 'text-emerald-600',
    borderColor: 'border-emerald-500',
    bgColor: 'bg-emerald-50',
    description: 'Extracts core themes and structure from your uploaded files.'
  },
  EXPLANATION_ENGINE: {
    name: 'Explainer',
    icon: <Lightbulb className="w-5 h-5" />,
    color: 'text-amber-600',
    borderColor: 'border-amber-500',
    bgColor: 'bg-amber-50',
    description: 'Synthesizes detailed notes and simplified explanations.'
  },
  QUIZ_MASTER: {
    name: 'Quiz Master',
    icon: <CheckSquare className="w-5 h-5" />,
    color: 'text-purple-600',
    borderColor: 'border-purple-500',
    bgColor: 'bg-purple-50',
    description: 'Generates assessments directly from document content.'
  },
  FLASHCARD_CREATOR: {
    name: 'Flashcard Creator',
    icon: <Layout className="w-5 h-5" />,
    color: 'text-rose-600',
    borderColor: 'border-rose-500',
    bgColor: 'bg-rose-50',
    description: 'Distills key terms into study cards.'
  },
  CRITIC: {
    name: 'Quality Reviewer',
    icon: <MessageSquareQuote className="w-5 h-5" />,
    color: 'text-blue-600',
    borderColor: 'border-blue-500',
    bgColor: 'bg-blue-50',
    description: 'Ensures factual accuracy relative to the original source.'
  },
  USER: {
    name: 'You',
    icon: <User className="w-5 h-5" />,
    color: 'text-slate-700',
    borderColor: 'border-slate-400',
    bgColor: 'bg-white',
    description: 'The learner.'
  }
};
